
/**
 * Write a description of class Sides here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sides extends Meals
{
    private String name;
    private double price;
    
    public Sides()
    {
        super();
        name = null;
        price = 0.0;
    }
    
    public Sides(String m, double p, boolean a, String n, double pr)
    {
        super(m,p,a);
        name = n;
        price = pr;
    } 
    
    
    public void setSides(String n) { name = n;}
    public void setSidesPrice (double p) { price = p;}
    
    
    public String getSides() {return name;}
    
    @Override
    public double getSidesPrice() {return price;}
    
    
    
    public boolean checkAvailable()
    {
        return super.checkAvailable();
    }
    
    public String toString()
    {
        return("Name : " + name + "Price : " + price);    
    }
  
}
