
/**
 * Write a description of class Customer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;
public class Customer
{
    private String username;
    private String password;
    
    public Customer()
    {
        username = null;
        password = null;
    }
    
    public Customer(String u, String p)
    {
        username = u;
        password = p;
    }
    
    public String getUsername() {return username;}
    
    public void login() 
    {
        int choice = 0;
        String line = "";
        boolean loginCheck = false;
        Scanner s = new Scanner(System.in);
        
        try 
        {
            File f = new File("custLoginDetails.txt");
            
            do
            {
                System.out.println("Would you like to login or create a new account?");
                System.out.println("1. Login");
                System.out.println("2. Create a new account");
                choice = Integer.parseInt(s.nextLine());
                
                if (choice != 1 && choice != 2)
                {
                    System.out.println("Wrong choice please try again");
                }
                
            } while (choice != 1 && choice != 2);
            
            
            System.out.println("Username:");
            username = s.nextLine();
            
            System.out.println("Password:");
            password = s.nextLine();
            
            if (choice == 1)
            {
                FileReader fr = new FileReader(f);
                BufferedReader br = new BufferedReader(fr);
                while ((line = br.readLine()) != null)
                {
                    StringTokenizer st = new StringTokenizer(line, ";");
                    String readUsername = st.nextToken();
                    String readPassword = st.nextToken();
                        
                    if (username.equals(readUsername) && password.equals(readPassword))
                    {
                        loginCheck = true;
                        break;
                    }
                    else
                    {
                        loginCheck = false;
                    }
                    
                }
                if (loginCheck)
                {
                    System.out.println("Welcome back! " + username );    
                }
                else
                {
                    do
                    {
                        System.out.println("Incorrect Login Details please try again");
                       
                        System.out.println("Username:");
                        username = s.nextLine();
            
                        System.out.println("Password:");
                        password = s.nextLine();
                       
                        fr = new FileReader(f);
                        br = new BufferedReader(fr);
                        while ((line = br.readLine()) != null)
                        {   
                            StringTokenizer st = new StringTokenizer(line, ";");
                            String readUsername = st.nextToken();
                            String readPassword = st.nextToken();
                        
                            if (username.equals(readUsername) && password.equals(readPassword))
                            {
                                loginCheck = true;
                                break;
                            }
                            else
                            {
                                loginCheck = false;
                            }
                        }
                        
                    }while (!loginCheck);
                    
                    System.out.println("Welcome back! " + username );
                }
                fr.close();
                br.close();
            }
            
            else
            {
                FileWriter login = new FileWriter("custloginDetails.txt", true);
                PrintWriter loginWrite = new PrintWriter(login);
                loginWrite.println(username + ";" + password);
                loginCheck = true;
                System.out.println("Account created successfully!");
                System.out.println("Welcome! " + username);
                loginWrite.close();
                login.close();
            }

            
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error opening file");
        }
        
    }
}
