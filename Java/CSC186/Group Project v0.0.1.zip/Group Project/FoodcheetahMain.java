
/**
 * Write a description of class FoodcheetahMain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import java.text.*;
public class FoodcheetahMain
{
    public static void main (String args[]) throws IOException
    {
        try
        {
            String line = "", mainCourse = "", restaurantChoice = "", sides = "", drinks = "", mealsFileName = "";
            int num = 0, mChoice, rChoice, sChoice, dChoice, paymentChoice, choice, availableUp, numMeals = 0, numSides = 6, numDrinks = 12;
            double paymentInput;
            boolean available = false;            
            Restaurant rest = new Restaurant();
            Restaurant [] r = new Restaurant[4];
            Meals [] m = new Meals[18];
            
            DecimalFormat df = new DecimalFormat("###.##");
            
            Scanner in = new Scanner(System.in);
            
            System.out.println("Welcome to FOODCHEETAH!");
            
            
            
            //Login System for Customer or Restaurant
            
            Customer cust = new Customer();
            
            do
            {
                System.out.println("Are you a customer or restaurant?");
                System.out.println("1. Customer");
                System.out.println("2. Restaurant");
                choice = Integer.parseInt(in.nextLine()); 

            } while (choice != 1 && choice != 2);
                
            if (choice == 1)
            {
                cust.login();    
            }
            else 
            {
                rest.login();
                
                do
                {
                    System.out.println("What would you like to do?");
                    System.out.println("1. Change availability of meals");
                    System.out.println("2. See receipt history");
                    rChoice = Integer.parseInt(in.nextLine());
                    if (rChoice < 1 && rChoice > 2)
                    {
                        System.out.println("Wrong Input please try again");
                    }
                } while (rChoice < 1 && rChoice > 2);
                
                if (rChoice == 1)
                {
                    File fChoice = new File ("restaurant.txt");
                    FileReader frChoice = new FileReader (fChoice);
                    BufferedReader brChoice = new BufferedReader (frChoice);
                                    
                    while((line = brChoice.readLine()) != null)
                    {
                        StringTokenizer st = new StringTokenizer (line, ";");
                        String rName = st.nextToken();
                        String rLocation = st.nextToken();
                            
                        r[num] = new Restaurant(rName, rLocation);
                        num++;
                    }
                    frChoice.close();
                    brChoice.close();
                    
                    for (int i = 0; i < r.length; i++)
                    {
                        restaurantChoice += (i + 1) + "." + r[i].getName() + " " + r[i].getLocation() + "\n"; 
                    }
                    
                    System.out.println(restaurantChoice);
                    
                    do
                    {
                        System.out.println("Which restaurant would you like to change?");
                        rChoice = Integer.parseInt(in.nextLine());
                        if (rChoice < 1 && rChoice > 4)
                        {
                            System.out.println("Wrong choice please try again");
                        }
                    } while (rChoice < 1 && rChoice > 4);
                    
                    
                    num = 0;
                    
                    if (rChoice == 1)
                    {
                        File f = new File ("meals.txt");
                        FileReader fr = new FileReader (f);
                        BufferedReader br = new BufferedReader (fr);
                        mealsFileName = "meals.txt";
                        while((line = br.readLine()) != null)
                        {
                            StringTokenizer st = new StringTokenizer (line, ";");
                            String readMainCourse = st.nextToken();
                            double readMainCoursePrice = Double.parseDouble(st.nextToken());
                            String readSides = st.nextToken();
                            double readSidesPrice = Double.parseDouble(st.nextToken());
                            String readDrinks = st.nextToken();
                            double readDrinksPrice = Double.parseDouble(st.nextToken());
                            boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                            
                            m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                            m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                            m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                            numMeals++;
                            numSides++;
                            numDrinks++;
                        }
                        fr.close();
                        br.close();
                    }
                    else if (rChoice == 2)
                    {
                        File f = new File ("meals2.txt");
                        FileReader fr = new FileReader (f);
                        BufferedReader br = new BufferedReader (fr);
                        mealsFileName = "meals2.txt";
                        while((line = br.readLine()) != null)
                        {
                            StringTokenizer st = new StringTokenizer (line, ";");
                            String readMainCourse = st.nextToken();
                            double readMainCoursePrice = Double.parseDouble(st.nextToken());
                            String readSides = st.nextToken();
                            double readSidesPrice = Double.parseDouble(st.nextToken());
                            String readDrinks = st.nextToken();
                            double readDrinksPrice = Double.parseDouble(st.nextToken());
                            boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                            
                            m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                            m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                            m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                            numMeals++;
                            numSides++;
                            numDrinks++;
                        }
                        fr.close();
                        br.close();
                    }
                    else if (rChoice == 3)
                    {
                        File f = new File ("meals3.txt");
                        FileReader fr = new FileReader (f);
                        BufferedReader br = new BufferedReader (fr);
                        mealsFileName = "meals3.txt";
                        while((line = br.readLine()) != null)
                        {
                            StringTokenizer st = new StringTokenizer (line, ";");
                            String readMainCourse = st.nextToken();
                            double readMainCoursePrice = Double.parseDouble(st.nextToken());
                            String readSides = st.nextToken();
                            double readSidesPrice = Double.parseDouble(st.nextToken());
                            String readDrinks = st.nextToken();
                            double readDrinksPrice = Double.parseDouble(st.nextToken());
                            boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                            
                            m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                            m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                            m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                            numMeals++;
                            numSides++;
                            numDrinks++;
                        }
                        fr.close();
                        br.close();
                    }
                    else
                    {
                        File f = new File ("meals4.txt");
                        FileReader fr = new FileReader (f);
                        BufferedReader br = new BufferedReader (fr);
                        mealsFileName = "meals4.txt";
                        while((line = br.readLine()) != null)
                        {
                            StringTokenizer st = new StringTokenizer (line, ";");
                            String readMainCourse = st.nextToken();
                            double readMainCoursePrice = Double.parseDouble(st.nextToken());
                            String readSides = st.nextToken();
                            double readSidesPrice = Double.parseDouble(st.nextToken());
                            String readDrinks = st.nextToken();
                            double readDrinksPrice = Double.parseDouble(st.nextToken());
                            boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                                
                            m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                            m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                            m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                            numMeals++;
                            numSides++;
                            numDrinks++;
                        }
                        fr.close();
                        br.close();
                        
                    }
                    
                    
                    
                    for (int i = 0; i < numMeals; i++) 
                    {
                        if (m[i].checkAvailable())
                            System.out.println((i + 1) + "." + m[i].getMainCourse() + " Available: Yes ");
                        else
                            System.out.println((i + 1) + "." + m[i].getMainCourse() + " Available: No ");
                    }
                    
                    do
                    {
                        System.out.println("Which meal would you like to change availability?");
                        mChoice = Integer.parseInt(in.nextLine());
                        if (mChoice < 1 && mChoice > 6)
                        {
                             System.out.println("Wrong Input please try again!");   
                        }
                    } while (mChoice < 1 && mChoice > 6);
                    
                    Meals selectedMeal = m[mChoice - 1];
                    
                    do
                    {
                        System.out.println("Do you want to set it available or not available?");
                        System.out.println("1. Available");
                        System.out.println("2. Not Available");
                        availableUp = Integer.parseInt(in.nextLine());
                        if (availableUp == 1)
                            available = true;
                        else if (availableUp == 2)
                            available = false;
                        else
                            System.out.println("Wrong Input Please try again");
                    } while (availableUp != 1 && availableUp != 2);
                    
                    selectedMeal.setAvailable(available);
                    
                    FileWriter mealWrite = new FileWriter(mealsFileName + ".tmp");
                    PrintWriter mealPrint = new PrintWriter(mealWrite);
                    
                    for (int i = 0; i < numMeals; i++) 
                    {
                        Sides side = (Sides) m[i + 6];
                        Drinks drink = (Drinks) m[i + 12];
                        
                        mealPrint.println(m[i].getMainCourse() + ";" + m[i].getMainCoursePrice() + ";" + side.getSides() + ";" + side.getSidesPrice() + ";" + drink.getDrinks() + ";" + drink.getDrinksPrice() + ";" + m[i].checkAvailable());
                        
                    }
                    

                    mealWrite.close();
                    mealPrint.close();
                    
                    
                    File originalFile = new File(mealsFileName);
                    File tempFile = new File(mealsFileName + ".tmp");
                    
                    originalFile.delete();
                    
                    if (tempFile.renameTo(originalFile)) 
                    {
                        System.out.println("File updated successfully.");
                    } 
                    else 
                    {
                        System.out.println("Error updating/renaming file.");
                    } 
                    
                }
                else
                {
                    rest.receiptHistory();
                }
                
                
                System.exit(0);
            }
            
            
            //Pick Restaurant
            File fChoice = new File ("restaurant.txt");
            FileReader frChoice = new FileReader (fChoice);
            BufferedReader brChoice = new BufferedReader (frChoice);
            
            num = 0;
            
            while((line = brChoice.readLine()) != null)
            {
                StringTokenizer st = new StringTokenizer (line, ";");
                String rName = st.nextToken();
                String rLocation = st.nextToken();
                
                r[num] = new Restaurant(rName, rLocation);
                num++;
            }
            frChoice.close();
            brChoice.close();
            
            for (int i = 0; i < r.length; i++)
            {
                restaurantChoice += (i + 1) + "." + r[i].getName() + " " + r[i].getLocation() + "\n"; 
            }
            
            System.out.println(restaurantChoice);
            do
            {
                System.out.println("Which restaurant would you like?");
                rChoice = Integer.parseInt(in.nextLine());
                if (rChoice < 1 && rChoice > 4)
                {
                    System.out.println("Wrong choice please try again");
                }
            } while (rChoice < 1 && rChoice > 4);
            
            
            
            //Order Meals
            
            num = 0;
            if (rChoice == 1)
            {
                File f = new File ("meals.txt");
                FileReader fr = new FileReader (f);
                BufferedReader br = new BufferedReader (fr);
                while((line = br.readLine()) != null)
                {
                    StringTokenizer st = new StringTokenizer (line, ";");
                    String readMainCourse = st.nextToken();
                    double readMainCoursePrice = Double.parseDouble(st.nextToken());
                    String readSides = st.nextToken();
                    double readSidesPrice = Double.parseDouble(st.nextToken());
                    String readDrinks = st.nextToken();
                    double readDrinksPrice = Double.parseDouble(st.nextToken());
                    boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                
                    m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                    m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                    m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                    numMeals++;
                    numSides++;
                    numDrinks++;
                }
                fr.close();
                br.close();
            }
            else if (rChoice == 2)
            {
                File f = new File ("meals2.txt");
                FileReader fr = new FileReader (f);
                BufferedReader br = new BufferedReader (fr);
                while((line = br.readLine()) != null)
                {
                    StringTokenizer st = new StringTokenizer (line, ";");
                    String readMainCourse = st.nextToken();
                    double readMainCoursePrice = Double.parseDouble(st.nextToken());
                    String readSides = st.nextToken();
                    double readSidesPrice = Double.parseDouble(st.nextToken());
                    String readDrinks = st.nextToken();
                    double readDrinksPrice = Double.parseDouble(st.nextToken());
                    boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                
                    m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                    m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                    m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                    numMeals++;
                    numSides++;
                    numDrinks++;
                }
                fr.close();
                br.close();
            }
            else if (rChoice == 3)
            {
                File f = new File ("meals3.txt");
                FileReader fr = new FileReader (f);
                BufferedReader br = new BufferedReader (fr);
                while((line = br.readLine()) != null)
                {
                    StringTokenizer st = new StringTokenizer (line, ";");
                    String readMainCourse = st.nextToken();
                    double readMainCoursePrice = Double.parseDouble(st.nextToken());
                    String readSides = st.nextToken();
                    double readSidesPrice = Double.parseDouble(st.nextToken());
                    String readDrinks = st.nextToken();
                    double readDrinksPrice = Double.parseDouble(st.nextToken());
                    boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                
                    m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                    m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                    m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                    numMeals++;
                    numSides++;
                    numDrinks++;
                }
                fr.close();
                br.close();
            }
            else
            {
                File f = new File ("meals4.txt");
                FileReader fr = new FileReader (f);
                BufferedReader br = new BufferedReader (fr);
                while((line = br.readLine()) != null)
                {
                    StringTokenizer st = new StringTokenizer (line, ";");
                    String readMainCourse = st.nextToken();
                    double readMainCoursePrice = Double.parseDouble(st.nextToken());
                    String readSides = st.nextToken();
                    double readSidesPrice = Double.parseDouble(st.nextToken());
                    String readDrinks = st.nextToken();
                    double readDrinksPrice = Double.parseDouble(st.nextToken());
                    boolean readAvailable = Boolean.parseBoolean(st.nextToken());
                
                    m[numMeals] = new Meals(readMainCourse, readMainCoursePrice, readAvailable);
                    m[numSides] = new Sides(readMainCourse, readMainCoursePrice, readAvailable, readSides, readSidesPrice);
                    m[numDrinks] = new Drinks(readMainCourse, readMainCoursePrice, readAvailable, readDrinks, readDrinksPrice);
                    numMeals++;
                    numSides++;
                    numDrinks++;
                }
                fr.close();
                br.close();
            }
            
            
            for (int i = 0; i < numMeals; i++)
            {
                if (m[i].checkAvailable())
                {
                    mainCourse += (i + 1) +"." + m[i].getMainCourse() + " RM" + m[i].getMainCoursePrice() + "\n";
                }
            }
            
            System.out.println(mainCourse);
            
            
            do
            {
                System.out.println("What food would you like?");
                mChoice = Integer.parseInt(in.nextLine());
                if (mChoice < 1 && mChoice > 6)
                {
                    System.out.println("Wrong choice please try again");
                }
            } while (mChoice < 1 && mChoice > 6);
            
            
            Meals selectedMeal = m[mChoice - 1];
            System.out.println("\n" + "You selected: " + selectedMeal.getMainCourse() + " RM" + selectedMeal.getMainCoursePrice() + "\n" );

            
            
            for (int i = 6; i < numSides; i++)
            {
                if (m[i].checkAvailable())
                {
                    sides += (num + 1) +"." + m[i].getSides() + " RM" + m[i].getSidesPrice() + "\n";
                    num++;
                }
            }
            
            System.out.println(sides);
            
            Sides sideChosen = new Sides();
            do
            {
                System.out.println("What Sides would you like?");
                sChoice = Integer.parseInt(in.nextLine());
                if (sChoice < 1 && sChoice > 6)
                {
                    System.out.println("Wrong choice please try again");
                }
                else
                {
                    Sides s = (Sides) m [sChoice + 5];
                    sideChosen.setSides(s.getSides());
                    sideChosen.setSidesPrice(s.getSidesPrice());  
                }
            } while (sChoice < 1 && sChoice > 6);
            
            System.out.println("\n " + "You selected: " + sideChosen.getSides() + " RM" + sideChosen.getSidesPrice() + "\n" );
            
            num = 0;
            
            for (int i = 12; i < numDrinks; i++)
            {
                if (m[i].checkAvailable())
                {
                    drinks += (num + 1) +"." + m[i].getDrinks() + " RM" + m[i].getDrinksPrice() + "\n";
                    num++;
                }
            }
            
            System.out.println(drinks);
            
            Drinks drinkChosen = new Drinks();
            do
            {
                System.out.println("What Drinks would you like?");
                dChoice = Integer.parseInt(in.nextLine());
                if (dChoice < 1 && dChoice > 6)
                {
                    System.out.println("Wrong choice please try again");
                }
                else
                {
                    Drinks d = (Drinks) m [dChoice + 11];
                    drinkChosen.setDrinks(d.getDrinks());
                    drinkChosen.setDrinksPrice(d.getDrinksPrice());
                }
            } while (dChoice < 1 && dChoice > 6);
            
            System.out.println("\n" + "You selected: " + drinkChosen.getDrinks() + " RM" + drinkChosen.getDrinksPrice() + "\n" );
            
            
            selectedMeal.setSidesPrice(sideChosen.getSidesPrice());
            selectedMeal.setDrinksPrice(drinkChosen.getDrinksPrice());

            double totalPrice = selectedMeal.calcPrice();
            
            Receipt rec = new Receipt(cust, r[rChoice - 1], m[mChoice - 1], totalPrice );
            
            do
            {
                System.out.println ("Total To Pay: RM" + df.format(totalPrice));
                System.out.println ("How would you like to pay?");
                System.out.println ("1. Cash");
                System.out.println ("2. FPX");
                System.out.println ("3. Credit/Debit card");
                
                paymentChoice = Integer.parseInt(in.nextLine());
    
                if(paymentChoice < 1 && paymentChoice > 3 )
                {
                    System.out.println("Wrong choice Please try again!");
                }
            
            } while(paymentChoice < 1 && paymentChoice > 3);
    
            
            do
            {
                System.out.println("Input amount : RM " );
                paymentInput = Double.parseDouble(in.nextLine());
    
                if(paymentInput < totalPrice)
                {
                    System.out.println("You don't have enough to complete this transcation, please try again");
                    System.out.println ("Total To Pay: RM" + df.format(totalPrice));
                }
                
            } while(paymentInput < totalPrice);
            
            
            
            rec.setPay(paymentInput);
            
            System.out.println(rec.printReceipt());
            
            in.close();
            
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error reading files");
        }
        
    }
}