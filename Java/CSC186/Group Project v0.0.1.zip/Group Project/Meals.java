
/**
 * Write a description of class Meals here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Meals
{
    private String mainCourse;
    private double mainCoursePrice, sPrice, dPrice;
    private boolean available;
    
    //default
    public Meals()
    {
        mainCourse = null;
        mainCoursePrice = 0.0;
        available = false;
    }
    
    //normal
    public Meals(String m, double p, boolean a)
    {
        mainCourse = m;
        mainCoursePrice = p;
        available = a;
    }
    
    
    //setters
    public void setAvailable(boolean a) {available = a;}
    public void setSidesPrice(double sp) { sPrice = sp;}
    public void setDrinksPrice(double dp) { dPrice = dp;}
    //getters
    public String getMainCourse() {return mainCourse;}
    public double getMainCoursePrice() {return mainCoursePrice;}
    public String getSides() {return null;}
    public double getSidesPrice() {return 0.0;}
    public String getDrinks() {return null;}
    public double getDrinksPrice() {return 0.0;}
    
    
    public double calcPrice()
    {
        return (sPrice + dPrice + mainCoursePrice);
    }
    
    public boolean checkAvailable()
    {
        return available;
    }
}
