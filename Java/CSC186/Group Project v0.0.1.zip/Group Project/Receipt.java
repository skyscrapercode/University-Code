
/**
 * Write a description of class Receipt here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.*;
import java.text.*;
import java.io.*;
public class Receipt
{
    // instance variables
    private Customer cust;
    private Restaurant rest;
    private Meals meal;
    private double pay;
    
    //normal constructor
    public Receipt(Customer c, Restaurant r, Meals m, double p)
    {
        cust = c;
        rest = r;
        meal = m;
        pay = p;
    }
    
    //setter@getter
    public void setPay(double p){pay = p;}
    public double getPay(){return pay;}
    
    //payment calculation
    public double calcPayment()
    {
        return (getPay() - (meal.calcPrice()));
    }

    //Displaying receipt
     public String printReceipt() 
    {
        Time clock = new Time();
        
        DecimalFormat df = new DecimalFormat("###.##");
        
        String str = "";
        str += "FoodCheetah \nYour Favourite food Ordering Companion!";
        str += "\n**************";
        str += "\n             Customer: " + cust.getUsername();
        str += "\n             Restaurant: " + rest.getName();
        str += "\n             Location: " + rest.getLocation();
        str += "\n             Order Time: " + clock.getTime();
        str += "\n             Order Will Be Ready By: " + clock.getRandomTime();
        str += "\n             Total Price: RM" + df.format(meal.calcPrice());
        str += "\n             Balance: RM" + df.format(calcPayment()); 
        str += "\n**************";
        
        try
        {
            FileWriter history = new FileWriter("receiptHistory.txt", true);
            PrintWriter historyWrite = new PrintWriter(history);
            historyWrite.println(cust.getUsername() + ";" + rest.getName() + ";" + rest.getLocation() + ";" + clock.getTime() + ";" + clock.getRandomTime()
             + ";" + df.format(meal.calcPrice()) + ";" + df.format(calcPayment()));
            historyWrite.close();
            history.close();
        }
        catch (IOException e)
        {
            System.out.println("Error Opening file");
        }
        return str;
    }
}