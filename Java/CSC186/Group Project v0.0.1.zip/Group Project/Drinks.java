
/**
 * Write a description of class Drinks here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Drinks extends Meals
{
    private String name;
    private double price;
    
    public Drinks()
    {
        super();
        name = null;
        price = 0.0;
    }
    
    public Drinks(String m, double p, boolean a, String n, double pr)
    {
        super(m,p,a);
        name = n;
        price = pr;
    } 
    
    
    public void setDrinks(String n) { name = n;}
    public void setDrinksPrice(double p) { price = p;}

    public String getDrinks() {return name;}
    
    @Override
    public double getDrinksPrice() {return price;}
    
    
    
    public String toString()
    {
        return("Name : " + name + "Price : " + price);    
    }
    
    
    
}